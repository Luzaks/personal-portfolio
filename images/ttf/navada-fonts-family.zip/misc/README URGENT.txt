Hello There.
Thank for downloading Navada
This demo font is for PERSONAL USE ONLY, but if youneed a commercial license that 
can be purchased here:
https://sabrcreative.com/product/navada/


For Donation at: paypal.me/irpanMau


For Your Huge Projects, you can see Full Version(Commercial Use) on our shop below: 
http://sabrcreative.com


If there is a problem, question, or anything about our fonts, 
please sent us an email to:
hello@sabrcreative.com


All forms of use of fonts without buying a license first must comply with our terms of 
completing purchases for commercial purposes and will be subject to a Corporate License.


Thank You So Much
Sabrcreative 
